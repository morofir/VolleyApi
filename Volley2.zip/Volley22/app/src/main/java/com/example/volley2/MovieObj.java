package com.example.volley2;

public class MovieObj {

}
